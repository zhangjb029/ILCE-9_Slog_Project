#!/bin/sh
# A9_V5_PACKAGE_ID=8cac6722199f2462
# Verify and stage data into RAM. Never execute a staged runtime artifact.
set -uf
umask 077
export PATH=/usr/bin:/bin:/sbin:/usr/sbin
BB=/bin/busybox
ROOT=/tmp_bt/a9-film-boot-stage
RAM=/tmp_bt
STAGE=$RAM/a9-film-stage.lock
fail() { echo "FILM_STAGE_FAIL stage=$1"; exit 1; }
hash_is() {
    test -f "$1" && test ! -L "$1" || return 1
    if hash_line=$("$BB" sha256sum "$1" 2>/dev/null); then
        test "${hash_line%% *}" = "$2"
        return $?
    fi
    hash_line=$(/usr/bin/openssl dgst -sha256 "$1" 2>/dev/null) || return 1
    test "${hash_line##* }" = "$2"
}
if test -e /tmp/disable_hook || test -e "$RAM/a9-film.DISABLE" ||
   test -e "$RAM/a9-film-capture.stop"; then
    echo FILM_STAGE_DISABLED
    exit 10
fi
test -d "$ROOT" && test ! -L "$ROOT" || fail source_directory
# Check every source before copying even the first executable.
while read -r name dest expected mode; do
    hash_is "$ROOT/$name" "$expected" || fail "source_hash-$name"
    test ! -e "$RAM/$dest" && test ! -L "$RAM/$dest" || fail "existing-$dest"
done <<'FILM_ARTIFACTS'
a9-check-persist.req a9-check-persist.req b54b53915f4d55eb02561c78bd3efee4d0b1f21d8c2244258dc0a3758eeb5ceb 644
a9-extra-menu-guard.elf a9-extra-menu-guard.elf f8bd0b6c4fad51c6c4eb13be9d8f4390da4aeaf00280bc334bbbc87ff1d403f8 755
a9-extra-menu.so a9-extra-menu.so 434dc319ca02da074c1ad533d7a50807c962e11ba6f3e40d025d34dcc931884f 755
a9-install-persist.req a9-install-persist.req cb84e0d54921b38fc9085c887b0500cdf3bcb09fd9c82c4c6fd2af3f947275f9 644
a9-remove-persist.req a9-remove-persist.req f2cb3f7bddf4fe8f2cb032a2e915bd4e151c200317a4c68d03b20cc79c920522 644
a9-wps-boot.elf a9-wps-boot.elf 7cb5ea95bc0294bc6eddcaa755098ce391cb25069f8d49fdbaddb821e6f2ceba 755
runtime-start.sh a9-film-runtime-start.sh 50ad0b9e88659fdf2cb29f99f425302ddd9c9922dd04fa1b534644716a8212bd 755
FILM_ARTIFACTS
test ! -e "$RAM/a9-film-staged" && test ! -L "$RAM/a9-film-staged" || fail existing_receipt
"$BB" mkdir "$STAGE" || fail existing_stage
{ echo "phase=copying"; echo "pid=$$"; } > "$STAGE/manifest" || fail stage_manifest
while read -r name dest expected mode; do
    "$BB" cp "$ROOT/$name" "$RAM/$dest" || fail "copy-$dest"
    "$BB" chmod "$mode" "$RAM/$dest" || fail "mode-$dest"
    hash_is "$RAM/$dest" "$expected" || fail "copied_hash-$dest"
done <<'FILM_ARTIFACTS'
a9-check-persist.req a9-check-persist.req b54b53915f4d55eb02561c78bd3efee4d0b1f21d8c2244258dc0a3758eeb5ceb 644
a9-extra-menu-guard.elf a9-extra-menu-guard.elf f8bd0b6c4fad51c6c4eb13be9d8f4390da4aeaf00280bc334bbbc87ff1d403f8 755
a9-extra-menu.so a9-extra-menu.so 434dc319ca02da074c1ad533d7a50807c962e11ba6f3e40d025d34dcc931884f 755
a9-install-persist.req a9-install-persist.req cb84e0d54921b38fc9085c887b0500cdf3bcb09fd9c82c4c6fd2af3f947275f9 644
a9-remove-persist.req a9-remove-persist.req f2cb3f7bddf4fe8f2cb032a2e915bd4e151c200317a4c68d03b20cc79c920522 644
a9-wps-boot.elf a9-wps-boot.elf 7cb5ea95bc0294bc6eddcaa755098ce391cb25069f8d49fdbaddb821e6f2ceba 755
runtime-start.sh a9-film-runtime-start.sh 50ad0b9e88659fdf2cb29f99f425302ddd9c9922dd04fa1b534644716a8212bd 755
FILM_ARTIFACTS
echo "FILM_STAGE_PREPARED package=8cac6722199f2462 direct_menu=1" > "$RAM/a9-film-staged" || fail receipt
{ echo "phase=prepared"; echo "pid=$$"; } > "$STAGE/manifest" || fail stage_manifest
echo FILM_STAGE_PREPARED
