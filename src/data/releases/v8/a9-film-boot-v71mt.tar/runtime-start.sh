#!/bin/sh
# A9_V5_PACKAGE_ID=8cac6722199f2462
# RAM-only native-loader entry; never mount raw SD from the running camera.
set -uf
umask 077
export PATH=/usr/bin:/bin:/sbin:/usr/sbin
BB=/bin/busybox
RAM=/tmp_bt
MOUNTS=/proc/mounts
IM_PID=
COMM=
MAPS=
STATUS=
LOCK=$RAM/a9-film-runtime.lock
REQUEST=$RAM/a9-extra-menu-load.req
GUARD=$RAM/a9-extra-menu-guard.elf
request_ours=0
last_request_hash=
fail() { echo "FILM_RUNTIME_FAIL stage=$1"; exit 1; }
disabled() {
    test -e /tmp/disable_hook || test -e "$RAM/a9-film.DISABLE" ||
        test -e "$RAM/a9-film-capture.stop"
}
no_sd_mount() {
    test -r "$MOUNTS" || return 1
    while read -r source target type options rest; do
        case "$source" in /dev/mmca*|/dev/mmcblk*) return 1;; esac
    done < "$MOUNTS"
    return 0
}
hash_is() {
    test -f "$1" && test ! -L "$1" || return 1
    if hash_line=$("$BB" sha256sum "$1" 2>/dev/null); then
        test "${hash_line%% *}" = "$2"
        return $?
    fi
    hash_line=$(/usr/bin/openssl dgst -sha256 "$1" 2>/dev/null) || return 1
    test "${hash_line##* }" = "$2"
}
gate() { ! disabled && no_sd_mount; }
find_im_pid() {
    IM_PID=
    im_count=0
    set +f
    for p in /proc/[0-9]*/comm; do
        test -r "$p" || continue
        IFS= read -r c < "$p" || continue
        if test "$c" = im.elf; then
            p=${p#/proc/}
            IM_PID=${p%/comm}
            im_count=$((im_count+1))
        fi
    done
    set -f
    test "$im_count" = 1 || return 1
    COMM=/proc/$IM_PID/comm
    MAPS=/proc/$IM_PID/maps
    STATUS=/proc/$IM_PID/status
}
ready() {
    find_im_pid || return 1
    test -r "$COMM" && test -r "$MAPS" && test -r "$STATUS" || return 1
    IFS= read -r comm < "$COMM" || return 1
    test "$comm" = im.elf &&
        "$BB" grep -q '/usr/bin/im\.elf$' "$MAPS" &&
        "$BB" grep -q '/usr/lib/libObj\.so$' "$MAPS" &&
        "$BB" grep -q '/usr/lib/viewUnified2\.so$' "$MAPS"
}
guard_report_ok() {
    end_count=0
    end_bad=0
    while IFS= read -r line; do
        case "$line" in
            END\ *)
                end_count=$((end_count+1))
                set -- $line
                if test "$#" != 4; then end_bad=1;continue; fi
                number=${4#errno=}
                test "$1" = END && test "$2" = result=0 &&
                    test "$3" = "op=$guard_op" && test "$4" = "errno=$number" || end_bad=1
                case "$number" in ''|*[!0-9]*) end_bad=1;; esac;;
        esac
    done < "$guard_log"
    test "$end_count" = 1 && test "$end_bad" = 0
}
guard_step() {
    guard_name=$1
    guard_op=$2
    guard_hash=$3
    guard_log=$RAM/a9-film-runtime.$guard_name.log
    gate && ready && test "$IM_PID" = "$STABLE_IM_PID" || fail "guard_gate-$guard_name"
    hash_is "$GUARD" f8bd0b6c4fad51c6c4eb13be9d8f4390da4aeaf00280bc334bbbc87ff1d403f8 && hash_is "$RAM/a9-$guard_name-persist.req" "$guard_hash" || fail guard_pin
    if test "$request_ours" = 1; then
        hash_is "$REQUEST" "$last_request_hash" || fail request_drift
    else
        test ! -e "$REQUEST" && test ! -L "$REQUEST" || fail existing_request
    fi
    "$BB" cp "$RAM/a9-$guard_name-persist.req" "$REQUEST" || fail request_copy
    hash_is "$REQUEST" "$guard_hash" || fail request_copy_hash
    request_ours=1
    last_request_hash=$guard_hash
    "$GUARD" > "$guard_log" 2>&1
    guard_rc=$?
    "$BB" cat "$guard_log"
    test "$guard_rc" = 0 && guard_report_ok || fail "guard_result-$guard_name"
}
if disabled; then echo FILM_RUNTIME_DISABLED;exit 0;fi
no_sd_mount || fail linux_sd_mounted
test -f "$RAM/a9-film-staged" && test ! -L "$RAM/a9-film-staged" || fail missing_stage
while read -r name dest expected mode; do
    hash_is "$RAM/$dest" "$expected" || fail "artifact_hash-$dest"
done <<'FILM_ARTIFACTS'
a9-check-persist.req a9-check-persist.req b54b53915f4d55eb02561c78bd3efee4d0b1f21d8c2244258dc0a3758eeb5ceb 644
a9-extra-menu-guard.elf a9-extra-menu-guard.elf f8bd0b6c4fad51c6c4eb13be9d8f4390da4aeaf00280bc334bbbc87ff1d403f8 755
a9-extra-menu.so a9-extra-menu.so 434dc319ca02da074c1ad533d7a50807c962e11ba6f3e40d025d34dcc931884f 755
a9-install-persist.req a9-install-persist.req cb84e0d54921b38fc9085c887b0500cdf3bcb09fd9c82c4c6fd2af3f947275f9 644
a9-remove-persist.req a9-remove-persist.req f2cb3f7bddf4fe8f2cb032a2e915bd4e151c200317a4c68d03b20cc79c920522 644
a9-wps-boot.elf a9-wps-boot.elf 7cb5ea95bc0294bc6eddcaa755098ce391cb25069f8d49fdbaddb821e6f2ceba 755
FILM_ARTIFACTS
gate || fail pre_wps_gate
test ! -e "$RAM/a9-wps-boot.log" && test ! -L "$RAM/a9-wps-boot.log" || fail existing_wps_log
"$RAM/a9-wps-boot.elf" > "$RAM/a9-wps-boot.log" 2>&1
wps_rc=$?
"$BB" cat "$RAM/a9-wps-boot.log"
echo "FILM_WPS_BOOT result=$wps_rc cache=unconfirmed"
threads_of() {
    test -n "$STATUS" && test -r "$STATUS" || { echo 0; return 1; }
    while IFS= read -r line; do
        case "$line" in
            Threads:*) set -- $line; echo "${2:-0}"; return 0;;
        esac
    done < "$STATUS"
    echo 0
}
wait_count=0
while ! ready; do
    gate || fail waiting_gate
    if test "$wait_count" -ge 120; then
        set +f
        for p in /proc/[0-9]*/comm; do
            test -r "$p" && IFS= read -r c < "$p" && echo "DIAG_COMM $p=$c"
        done
        set -f
        fail im_not_ready
    fi
    if test "$((wait_count % 10))" = 0; then
        echo "FILM_WAIT_IM elapsed=${wait_count}s"
    fi
    "$BB" sleep 1
    wait_count=$((wait_count+1))
done
prev_threads=$(threads_of)
prev_pid=$IM_PID
settle_count=0
stable_hits=0
while test "$settle_count" -lt 20; do
    gate && ready || fail settle_gate
    "$BB" sleep 1
    gate && ready || fail settle_gate
    curr_threads=$(threads_of)
    case "$curr_threads" in ''|*[!0-9]*) curr_threads=0;; esac
    if test "$curr_threads" -gt 0 && test "$curr_threads" = "$prev_threads" &&
       test "$IM_PID" = "$prev_pid"; then
        stable_hits=$((stable_hits+1))
        test "$stable_hits" -ge 2 && break
    else
        stable_hits=0
    fi
    prev_threads=$curr_threads
    prev_pid=$IM_PID
    settle_count=$((settle_count+1))
done
test "$stable_hits" -ge 2 || fail im_not_stable
STABLE_IM_PID=$IM_PID
gate || fail pre_install_gate
"$BB" mkdir "$LOCK" || fail existing_runtime
{ echo "phase=guard_check"; echo "pid=$$"; echo "package=8cac6722199f2462"; } > "$LOCK/manifest" || fail manifest
guard_step check 0 b54b53915f4d55eb02561c78bd3efee4d0b1f21d8c2244258dc0a3758eeb5ceb
guard_step install 1 cb84e0d54921b38fc9085c887b0500cdf3bcb09fd9c82c4c6fd2af3f947275f9
# The original one-shot loader still waits for a natural touch release.
# The direct A9 module uses its existing R15 owner; no extra backend is run.
gate && ready && test "$IM_PID" = "$STABLE_IM_PID" || fail post_install_gate
{ echo "phase=ready"; echo "pid=$$"; echo "package=8cac6722199f2462"; echo "natural_touch_release_required=1"; } > "$LOCK/manifest" || fail manifest
echo FILM_RUNTIME_READY natural_touch_release_required=1 direct_menu=1
exit 0
