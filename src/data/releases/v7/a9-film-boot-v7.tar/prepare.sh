#!/bin/sh
# A9_V5_PACKAGE_ID=7aa8d1e6060d34b0
# Verify and stage data into RAM. Never execute a staged runtime artifact.
set -uf
umask 077
export PATH=/usr/bin:/bin:/sbin:/usr/sbin
BB=/bin/busybox
ROOT=/tmp_bt/a9-film-boot-stage
RAM=/tmp_bt
STAGE=$RAM/a9-film-stage.lock
fail() { echo "FILM_STAGE_FAIL stage=$1"; exit 1; }
hash_is() {
    test -f "$1" && test ! -L "$1" || return 1
    if hash_line=$("$BB" sha256sum "$1" 2>/dev/null); then
        test "${hash_line%% *}" = "$2"
        return $?
    fi
    hash_line=$(/usr/bin/openssl dgst -sha256 "$1" 2>/dev/null) || return 1
    test "${hash_line##* }" = "$2"
}
if test -e /tmp/disable_hook || test -e "$RAM/a9-film.DISABLE" ||
   test -e "$RAM/a9-film-capture.stop"; then
    echo FILM_STAGE_DISABLED
    exit 10
fi
test -d "$ROOT" && test ! -L "$ROOT" || fail source_directory
# Check every source before copying even the first executable.
while read -r name dest expected mode; do
    hash_is "$ROOT/$name" "$expected" || fail "source_hash-$name"
    test ! -e "$RAM/$dest" && test ! -L "$RAM/$dest" || fail "existing-$dest"
done <<'FILM_ARTIFACTS'
a9-check-persist.req a9-check-persist.req b54b53915f4d55eb02561c78bd3efee4d0b1f21d8c2244258dc0a3758eeb5ceb 644
a9-extra-menu-guard.elf a9-extra-menu-guard.elf 8bb7053753bffa16c756c2c53b9dfd362ed70039eb9cb5632ec5f891747156c2 755
a9-extra-menu.so a9-extra-menu.so f7f937cbb09924068189712a3d93913dca43c436f5d2e73204c5a51969a082e6 755
a9-install-persist.req a9-install-persist.req cb84e0d54921b38fc9085c887b0500cdf3bcb09fd9c82c4c6fd2af3f947275f9 644
a9-remove-persist.req a9-remove-persist.req f2cb3f7bddf4fe8f2cb032a2e915bd4e151c200317a4c68d03b20cc79c920522 644
a9-wps-boot.elf a9-wps-boot.elf 5c338b55f73ccd4994917075fb83478a2d66b840d406cd5becba51e229f524b7 755
runtime-start.sh a9-film-runtime-start.sh 69a843facc32d8dda20c024e926c3afd4ab9348eb6b27d5664dd58380aa65487 755
FILM_ARTIFACTS
test ! -e "$RAM/a9-film-staged" && test ! -L "$RAM/a9-film-staged" || fail existing_receipt
"$BB" mkdir "$STAGE" || fail existing_stage
{ echo "phase=copying"; echo "pid=$$"; } > "$STAGE/manifest" || fail stage_manifest
while read -r name dest expected mode; do
    "$BB" cp "$ROOT/$name" "$RAM/$dest" || fail "copy-$dest"
    "$BB" chmod "$mode" "$RAM/$dest" || fail "mode-$dest"
    hash_is "$RAM/$dest" "$expected" || fail "copied_hash-$dest"
done <<'FILM_ARTIFACTS'
a9-check-persist.req a9-check-persist.req b54b53915f4d55eb02561c78bd3efee4d0b1f21d8c2244258dc0a3758eeb5ceb 644
a9-extra-menu-guard.elf a9-extra-menu-guard.elf 8bb7053753bffa16c756c2c53b9dfd362ed70039eb9cb5632ec5f891747156c2 755
a9-extra-menu.so a9-extra-menu.so f7f937cbb09924068189712a3d93913dca43c436f5d2e73204c5a51969a082e6 755
a9-install-persist.req a9-install-persist.req cb84e0d54921b38fc9085c887b0500cdf3bcb09fd9c82c4c6fd2af3f947275f9 644
a9-remove-persist.req a9-remove-persist.req f2cb3f7bddf4fe8f2cb032a2e915bd4e151c200317a4c68d03b20cc79c920522 644
a9-wps-boot.elf a9-wps-boot.elf 5c338b55f73ccd4994917075fb83478a2d66b840d406cd5becba51e229f524b7 755
runtime-start.sh a9-film-runtime-start.sh 69a843facc32d8dda20c024e926c3afd4ab9348eb6b27d5664dd58380aa65487 755
FILM_ARTIFACTS
echo "FILM_STAGE_PREPARED package=7aa8d1e6060d34b0 direct_menu=1" > "$RAM/a9-film-staged" || fail receipt
{ echo "phase=prepared"; echo "pid=$$"; } > "$STAGE/manifest" || fail stage_manifest
echo FILM_STAGE_PREPARED
